<?php 
	$server = "localhost";
    $usser = "root";
    $key = "";
    $bd = "bd_productos";


 ?>